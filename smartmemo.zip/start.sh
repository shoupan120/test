#!/bin/bash

# 启动后端服务
python3 -m flask run --host=0.0.0.0 --port=8080 &

# 启动前端服务
npm start
