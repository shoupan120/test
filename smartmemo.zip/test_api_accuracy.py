"""
API解析准确性测试脚本
用于测试自然语言解析API的准确性
"""
import requests
import json
import time
from datetime import datetime

# 配置
API_URL = "http://127.0.0.1:8080/api/parse"
TEST_CASES = 10  # 测试用例数量
RESULTS_FILE = "api_test_results.json"

def run_test(test_input):
    """运行单个测试"""
    print(f"测试输入: {test_input}")
    
    try:
        # 发送API请求
        response = requests.post(
            API_URL,
            json={"text": test_input},
            timeout=30
        )
        
        # 检查响应状态
        if response.status_code != 200:
            print(f"API请求失败: HTTP {response.status_code}")
            return {
                "input": test_input,
                "success": False,
                "error": f"HTTP错误: {response.status_code}",
                "response": None
            }
        
        # 解析响应
        result = response.json()
        
        # 检查API响应是否成功
        if not result.get("success"):
            print(f"API返回错误: {result.get('message')}")
            return {
                "input": test_input,
                "success": False,
                "error": result.get("message"),
                "response": result
            }
        
        # 提取解析结果
        parsed_data = result.get("data", {})
        print(f"解析结果: {json.dumps(parsed_data, ensure_ascii=False, indent=2)}")
        
        return {
            "input": test_input,
            "success": True,
            "error": None,
            "response": parsed_data,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
    except Exception as e:
        print(f"测试过程中出错: {str(e)}")
        return {
            "input": test_input,
            "success": False,
            "error": str(e),
            "response": None
        }

def save_results(results):
    """保存测试结果到文件"""
    with open(RESULTS_FILE, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"测试结果已保存到 {RESULTS_FILE}")

def main():
    """主函数"""
    print("开始API解析准确性测试...")
    
    # 测试用例
    test_inputs = [
        "明天下午3点和张三开产品讨论会",
        "下周一上午10点提交季度报告，高优先级",
        "后天和市场部李四讨论营销方案",
        "下周三下午2点参加技术评审会议",
        "明天上午9点和人事部王五面试新员工",
        "下周五下午4点准备项目总结报告，低优先级",
        "大后天早上8点参加晨会",
        "下个月15日提交预算报告",
        "今天晚上8点回复客户邮件，高优先级",
        "下周二下午3点和财务部赵六对账"
    ]
    
    # 运行测试
    results = []
    for i, test_input in enumerate(test_inputs, 1):
        print(f"\n测试 {i}/{len(test_inputs)}")
        result = run_test(test_input)
        results.append(result)
        
        # 避免请求过于频繁
        if i < len(test_inputs):
            print("等待2秒...")
            time.sleep(2)
    
    # 保存结果
    save_results(results)
    
    # 打印摘要
    success_count = sum(1 for r in results if r["success"])
    print(f"\n测试完成: {success_count}/{len(results)} 成功")

if __name__ == "__main__":
    main()
