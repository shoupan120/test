"""
智能备忘录配置文件
包含应用的基本配置信息
"""
import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class Config:
    """应用配置类"""
    # 应用密钥
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-key-for-smart-memo'
    
    # 数据库配置
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///smart_memo.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # API配置
    AI_API_ENDPOINT = 'https://api.siliconflow.cn/v1/chat/completions'
    
    # 默认设置
    DEFAULT_MODEL = ""
    DEFAULT_API_KEY = ""
