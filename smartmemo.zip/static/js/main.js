/**
 * 智能备忘录 - 主JavaScript文件
 * 实现所有的前端交互逻辑
 */

// 全局变量
const API_BASE_URL = 'http://127.0.0.1:8080/api';
let currentEditingTodoId = null;
let deletingTodoId = null;
let isSavingTodo = false; // 防止重复保存的标志

/**
 * 将自然语言时间描述转换为具体的日期时间
 * @param {string} timeDescription - 时间描述，如"明天下午3点"
 * @returns {Date|null} - 返回转换后的Date对象，如果无法转换则返回null
 */
function convertTimeDescription(timeDescription) {
  if (!timeDescription) return null;
  
  console.log('转换时间描述:', timeDescription);
  
  // 获取当前日期和时间
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth(); // 0-11
  const currentDate = now.getDate();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();
  
  // 结果日期，默认为当前日期
  let resultDate = new Date(now);
  let timeSet = false; // 是否设置了具体时间
  
  // 处理相对日期
  if (timeDescription.includes('明天')) {
    resultDate.setDate(currentDate + 1);
  } else if (timeDescription.includes('后天')) {
    resultDate.setDate(currentDate + 2);
  } else if (timeDescription.includes('大后天')) {
    resultDate.setDate(currentDate + 3);
  } else if (timeDescription.includes('下周一') || timeDescription.includes('下星期一')) {
    // 计算下周一的日期
    const dayOfWeek = now.getDay(); // 0是周日，1是周一
    const daysUntilNextMonday = (dayOfWeek === 0) ? 1 : (8 - dayOfWeek);
    resultDate.setDate(currentDate + daysUntilNextMonday);
  } else if (timeDescription.includes('下周二') || timeDescription.includes('下星期二')) {
    const dayOfWeek = now.getDay();
    const daysUntilNextTuesday = (dayOfWeek === 0) ? 2 : (9 - dayOfWeek);
    resultDate.setDate(currentDate + daysUntilNextTuesday);
  } else if (timeDescription.includes('下周三') || timeDescription.includes('下星期三')) {
    const dayOfWeek = now.getDay();
    const daysUntilNextWednesday = (dayOfWeek === 0) ? 3 : (10 - dayOfWeek);
    resultDate.setDate(currentDate + daysUntilNextWednesday);
  } else if (timeDescription.includes('下周四') || timeDescription.includes('下星期四')) {
    const dayOfWeek = now.getDay();
    const daysUntilNextThursday = (dayOfWeek === 0) ? 4 : (11 - dayOfWeek);
    resultDate.setDate(currentDate + daysUntilNextThursday);
  } else if (timeDescription.includes('下周五') || timeDescription.includes('下星期五')) {
    const dayOfWeek = now.getDay();
    const daysUntilNextFriday = (dayOfWeek === 0) ? 5 : (12 - dayOfWeek);
    resultDate.setDate(currentDate + daysUntilNextFriday);
  } else if (timeDescription.includes('下周六') || timeDescription.includes('下星期六')) {
    const dayOfWeek = now.getDay();
    const daysUntilNextSaturday = (dayOfWeek === 0) ? 6 : (13 - dayOfWeek);
    resultDate.setDate(currentDate + daysUntilNextSaturday);
  } else if (timeDescription.includes('下周日') || timeDescription.includes('下星期日') || timeDescription.includes('下周天')) {
    const dayOfWeek = now.getDay();
    const daysUntilNextSunday = 7;
    resultDate.setDate(currentDate + daysUntilNextSunday);
  } else if (timeDescription.includes('下周') || timeDescription.includes('下星期')) {
    resultDate.setDate(currentDate + 7);
  } else if (timeDescription.includes('下个月') || timeDescription.includes('下月')) {
    resultDate.setMonth(currentMonth + 1);
  } else if (timeDescription.includes('明年')) {
    resultDate.setFullYear(currentYear + 1);
  }
  
  // 处理具体日期 (简单处理，实际应用可能需要更复杂的正则表达式)
  const dateMatch = timeDescription.match(/(\d{1,2})月(\d{1,2})日/);
  if (dateMatch) {
    const month = parseInt(dateMatch[1]) - 1; // 月份从0开始
    const day = parseInt(dateMatch[2]);
    resultDate.setMonth(month);
    resultDate.setDate(day);
    // 如果设置的日期已经过去，假设是明年的日期
    if (resultDate < now) {
      resultDate.setFullYear(currentYear + 1);
    }
  }
  
  // 处理具体时间
  let hourMatch = timeDescription.match(/(\d{1,2})点/);
  let hour = -1;
  
  if (hourMatch) {
    hour = parseInt(hourMatch[1]);
    timeSet = true;
    
    // 处理上午/下午/晚上
    if (timeDescription.includes('下午') || timeDescription.includes('晚上') || timeDescription.includes('傍晚')) {
      if (hour < 12) hour += 12;
    } else if (timeDescription.includes('上午') || timeDescription.includes('早上') || timeDescription.includes('早晨')) {
      if (hour === 12) hour = 0;
    }
    
    resultDate.setHours(hour);
    resultDate.setMinutes(0);
    resultDate.setSeconds(0);
  }
  
  // 处理分钟
  const minuteMatch = timeDescription.match(/(\d{1,2})分/);
  if (minuteMatch && hour !== -1) {
    const minute = parseInt(minuteMatch[1]);
    resultDate.setMinutes(minute);
    timeSet = true;
  }
  
  // 如果没有设置具体时间，默认为当天23:59:59
  if (!timeSet) {
    resultDate.setHours(23);
    resultDate.setMinutes(59);
    resultDate.setSeconds(59);
  }
  
  console.log('转换结果:', resultDate);
  return resultDate;
}

/**
 * 页面加载完成后初始化
 */
document.addEventListener('DOMContentLoaded', function() {
  console.log('应用初始化中...');
  
  // 获取版本号
  getAppVersion();
  
  // 加载设置
  loadSettings();
  
  // 加载待办事项
  loadTodos('false'); // 默认加载进行中的待办
  
  // 绑定事件监听器
  bindEventListeners();
  
  // 默认设置为夜晚模式
  document.body.classList.add('dark-theme');
});

/**
 * 获取应用版本号
 */
function getAppVersion() {
  fetch(`${API_BASE_URL}/version`)
    .then(response => response.json())
    .then(data => {
      console.log('应用版本:', data.version);
      // 在控制台显示版本号
      console.log(`智能备忘录 V${data.version} 已启动`);
      
      // 如果页面上有版本信息元素，则更新它
      const versionElement = document.querySelector('.app-header h1');
      if (versionElement) {
        versionElement.setAttribute('title', `V${data.version}`);
      }
    })
    .catch(error => {
      console.error('获取版本号失败:', error);
    });
}

/**
 * 初始化应用
 */
function initApp() {
  // 加载设置
  loadSettings();
  
  // 加载待办事项
  loadTodos('false'); // 默认加载进行中的待办
  
  // 绑定事件监听器
  bindEventListeners();
}

/**
 * 绑定事件监听器
 */
function bindEventListeners() {
  // 标签页切换
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.getAttribute('data-tab')));
  });
  
  // 设置按钮
  document.getElementById('settingsBtn').addEventListener('click', () => openModal('settingsModal'));
  
  // 保存设置表单提交
  document.getElementById('settingsForm').addEventListener('submit', saveSettings);
  
  // 添加待办按钮
  document.getElementById('addTodoBtn').addEventListener('click', openNewTodoModal);
  
  // 解析按钮
  document.getElementById('parseBtn').addEventListener('click', parseText);
  
  // 保存待办按钮
  document.getElementById('saveButton').addEventListener('click', saveTodo);
  
  // 确认删除按钮
  document.getElementById('confirmDeleteBtn').addEventListener('click', () => {
    deleteTodo(deletingTodoId);
    closeModals();
  });
  
  // 取消删除按钮
  document.getElementById('cancelDeleteBtn').addEventListener('click', closeModals);
  
  // 关闭按钮
  document.querySelectorAll('.close-btn').forEach(btn => {
    btn.addEventListener('click', closeModals);
  });
  
  // 点击模态框背景关闭
  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', event => {
      if (event.target === modal) {
        closeModals();
      }
    });
  });
  
  // 预览确认按钮
  document.getElementById('confirmPreviewBtn').addEventListener('click', confirmPreview);
  
  // 预览编辑按钮
  document.getElementById('editPreviewBtn').addEventListener('click', editPreview);
  
  // 日期筛选按钮
  document.getElementById('applyDateFilter').addEventListener('click', applyDateFilter);
  
  // 清除日期筛选按钮
  document.getElementById('clearDateFilter').addEventListener('click', clearDateFilter);
  
  // 按下ESC键关闭模态框
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      closeModals();
    }
  });
}

/**
 * 切换标签页
 * @param {string} tab - 标签页名称（'ongoing' 或 'completed'）
 */
function switchTab(tab) {
  // 更新标签页状态
  const tabButtons = document.querySelectorAll('.tab-btn');
  const ongoingContent = document.getElementById('ongoing-content');
  const completedContent = document.getElementById('completed-content');
  
  if (tab === 'ongoing') {
    // 更新标签按钮状态
    tabButtons.forEach(btn => {
      if (btn.getAttribute('data-tab') === 'ongoing') {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
    
    // 显示进行中内容，隐藏已完成内容
    ongoingContent.classList.remove('hidden');
    completedContent.classList.add('hidden');
    
    // 加载进行中的待办事项
    loadTodos('false');
  } else {
    // 更新标签按钮状态
    tabButtons.forEach(btn => {
      if (btn.getAttribute('data-tab') === 'completed') {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
    
    // 显示已完成内容，隐藏进行中内容
    ongoingContent.classList.add('hidden');
    completedContent.classList.remove('hidden');
    
    // 加载已完成的待办事项，应用当前日期筛选
    loadTodos('true', getCurrentDateFilter());
  }
}

/**
 * 打开模态框
 * @param {string} modalId - 模态框ID
 */
function openModal(modalId) {
  // 显示遮罩层
  document.querySelector('.modal-overlay').style.display = 'block';
  
  // 显示模态框
  const modal = document.getElementById(modalId);
  modal.classList.add('active');
}

/**
 * 关闭所有模态框
 */
function closeModals() {
  // 隐藏遮罩层
  document.querySelector('.modal-overlay').style.display = 'none';
  
  // 隐藏所有模态框
  document.querySelectorAll('.modal').forEach(modal => {
    modal.classList.remove('active');
  });
}

/**
 * 重置待办事项模态框
 */
function resetTodoModal() {
  // 重置表单
  document.getElementById('todoForm').reset();
  document.getElementById('todoId').value = '';
  
  // 重置原始时间描述字段
  const dueDateRawInput = document.getElementById('todoDueDateRaw');
  if (dueDateRawInput) {
    dueDateRawInput.value = '';
  }
  
  // 重置解析状态
  document.getElementById('parseStatus').innerHTML = '';
  document.getElementById('parseStatus').classList.add('hidden');
  
  // 隐藏预览区域
  const previewSection = document.getElementById('previewSection');
  previewSection.classList.remove('active');
  setTimeout(() => {
    previewSection.classList.add('hidden');
  }, 300);
  
  // 显示表单区域
  document.getElementById('todoFormSection').classList.remove('hidden');
  
  // 重置解析输入框
  document.getElementById('todoText').value = '';
  
  // 清除解析数据
  window.parsedTodoData = null;
  
  // 重置当前编辑的待办ID
  currentEditingTodoId = null;
  
  // 重置模态框标题
  document.getElementById('todoModalTitle').textContent = '添加待办事项';
  
  // 显示解析区域
  document.querySelector('.input-section').classList.remove('hidden');
}

/**
 * 显示提示消息
 * @param {string} message - 消息内容
 * @param {string} type - 消息类型：success, error, info, warning
 * @param {number} duration - 显示时长(毫秒)，默认3000ms
 */
function showToast(message, type = 'info', duration = 3000) {
  // 创建toast元素
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  // 设置图标
  let icon = '';
  switch(type) {
    case 'success':
      icon = '<i class="fas fa-check-circle"></i>';
      break;
    case 'error':
      icon = '<i class="fas fa-times-circle"></i>';
      break;
    case 'warning':
      icon = '<i class="fas fa-exclamation-triangle"></i>';
      break;
    default:
      icon = '<i class="fas fa-info-circle"></i>';
  }
  
  // 设置内容
  toast.innerHTML = `
    <div class="toast-content">
      ${icon}
      <span>${message}</span>
    </div>
  `;
  
  // 添加到页面
  document.body.appendChild(toast);
  
  // 显示动画
  setTimeout(() => {
    toast.classList.add('show');
  }, 10);
  
  // 自动关闭
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      document.body.removeChild(toast);
    }, 300);
  }, duration);
}

/**
 * 显示警告消息
 * @param {string} message - 消息内容
 */
function showAlert(message) {
  document.getElementById('alertMessage').textContent = message;
  openModal('alertModal');
}

/**
 * 加载设置
 */
function loadSettings() {
  fetch(`${API_BASE_URL}/settings`)
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        const modelName = data.data.model_name;
        const apiKey = data.data.api_key;
        
        document.getElementById('apiKey').value = apiKey;
        
        // 处理模型名称选择
        const modelSelect = document.getElementById('modelName');
        let modelExists = false;
        
        // 检查是否是预定义的模型
        for (let i = 0; i < modelSelect.options.length; i++) {
          if (modelSelect.options[i].value === modelName) {
            modelSelect.selectedIndex = i;
            modelExists = true;
            break;
          }
        }
        
        // 如果不是预定义模型，选择"自定义"选项并填充自定义字段
        if (!modelExists && modelName) {
          for (let i = 0; i < modelSelect.options.length; i++) {
            if (modelSelect.options[i].value === 'custom') {
              modelSelect.selectedIndex = i;
              document.getElementById('customModelName').style.display = 'block';
              document.getElementById('customModelName').value = modelName;
              break;
            }
          }
        }
      }
    })
    .catch(error => {
      console.error('获取设置失败:', error);
    });
}

/**
 * 保存设置
 */
function saveSettings(event) {
  // 阻止表单默认提交行为
  if (event) {
    event.preventDefault();
  }
  
  const modelSelect = document.getElementById('modelName');
  const customModelInput = document.getElementById('customModelName');
  const apiKey = document.getElementById('apiKey').value.trim();
  
  let modelName = modelSelect.value;
  
  // 如果是自定义模型，则使用自定义输入框的值
  if (modelName === 'custom') {
    modelName = customModelInput.value.trim();
    
    if (!modelName) {
      showToast('请输入自定义模型名称！');
      return;
    }
  }
  
  // 验证必填项
  if (!modelName || !apiKey) {
    showToast('模型名称和API密钥不能为空！');
    return;
  }
  
  const settings = {
    model_name: modelName,
    api_key: apiKey
  };
  
  fetch(`${API_BASE_URL}/settings`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(settings)
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        closeModals();
        showToast('设置保存成功！');
      } else {
        showToast(`保存失败: ${data.message || '未知错误'}`);
      }
    })
    .catch(error => {
      console.error('保存设置失败:', error);
      showToast('保存设置失败，请重试！');
    });
}

/**
 * 加载待办事项列表
 * @param {string} status - 状态过滤（'true'=已完成, 'false'=进行中）
 * @param {string} dateFilter - 日期筛选（可选，格式为YYYY-MM-DD）
 */
function loadTodos(status = 'false', dateFilter = null) {
  console.log(`加载待办事项列表，状态: ${status}, 日期筛选: ${dateFilter}`);
  
  // 显示加载状态
  const listContainer = status === 'true' ? 
    document.getElementById('completedList') : 
    document.getElementById('todoList');
  
  if (!listContainer) {
    console.error(`找不到列表容器，状态: ${status}`);
    return;
  }
  
  listContainer.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">加载中...</p></div>';
  
  // 构建URL，添加时间戳防止缓存
  const timestamp = new Date().getTime();
  let url = `${API_BASE_URL}/todos?status=${status}&_=${timestamp}`;
  
  // 如果有日期筛选，添加到URL
  if (dateFilter && status === 'true') {
    url += `&date=${dateFilter}`;
  }
  
  console.log(`发起请求: ${url}`);
  
  // 发起API请求
  fetch(url)
    .then(response => {
      console.log(`待办列表响应: ${response.status} ${response.statusText}`);
      
      if (!response.ok) {
        throw new Error(`HTTP错误! 状态: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      console.log(`待办列表加载成功，状态: ${status}，数量: ${data.data ? data.data.length : 0}`);
      
      if (data.success) {
        // 渲染待办列表
        renderTodoList(data.data, status);
      } else {
        throw new Error(data.message || '加载待办事项失败');
      }
    })
    .catch(error => {
      console.error(`加载待办事项失败，状态: ${status}:`, error);
      
      // 显示错误信息
      listContainer.innerHTML = `
        <div class="alert alert-danger">
          <i class="fas fa-exclamation-triangle"></i> 加载失败: ${error.message}
          <button class="btn btn-sm btn-outline-danger ms-2" onclick="loadTodos('${status}')">
            <i class="fas fa-sync-alt"></i> 重试
          </button>
        </div>
      `;
      
      // 显示错误提示
      showToast(`加载待办事项失败: ${error.message}`, 'error');
    });
}

/**
 * 渲染待办事项列表
 * @param {Array} todos - 待办事项数组
 * @param {string} status - 状态（'true'=已完成, 'false'=进行中）
 */
function renderTodoList(todos, status) {
  console.log(`渲染待办列表，状态: ${status}, 数量: ${todos.length}`);
  
  const listContainer = status === 'true' ? 
    document.getElementById('completedList') : 
    document.getElementById('todoList');
  
  // 如果没有待办事项
  if (!todos || todos.length === 0) {
    listContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-clipboard-list"></i>
        <p>${status === 'true' ? '没有已完成的待办事项' : '没有进行中的待办事项'}</p>
        ${status === 'false' ? '<button class="btn btn-primary mt-2" onclick="openNewTodoModal()"><i class="fas fa-plus"></i> 创建新待办</button>' : ''}
      </div>
    `;
    return;
  }
  
  // 构建HTML
  let html = '';
  
  todos.forEach(todo => {
    // HTML转义防止XSS攻击
    const title = escapeHtml(todo.title);
    const content = escapeHtml(todo.content || '');
    
    // 格式化日期
    let dueDateStr = '';
    if (todo.due_date) {
      const dueDate = new Date(todo.due_date);
      dueDateStr = dueDate.toLocaleDateString('zh-CN', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }
    
    // 格式化完成时间（仅对已完成项目）
    let completedTimeStr = '';
    if (status === 'true' && todo.updated_at) {
      const completedTime = new Date(todo.updated_at);
      completedTimeStr = completedTime.toLocaleDateString('zh-CN', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }
    
    // 优先级样式
    let priorityClass = '';
    let priorityText = '';
    
    switch(todo.priority) {
      case '高':
      case 'high':
        priorityClass = 'priority-高';
        priorityText = '高';
        break;
      case '中':
      case 'medium':
        priorityClass = 'priority-中';
        priorityText = '中';
        break;
      case '低':
      case 'low':
        priorityClass = 'priority-低';
        priorityText = '低';
        break;
      default:
        priorityClass = 'priority-中';
        priorityText = todo.priority || '中';
    }
    
    // 构建待办卡片
    html += `
      <div class="todo-item ${priorityClass}" data-id="${todo.id}">
        <div class="todo-actions">
          ${status === 'false' ? `
            <button class="todo-action-btn complete" onclick="updateTodoStatus(${todo.id}, true)" title="标记为已完成">
              <i class="fas fa-check"></i>
            </button>
          ` : `
            <button class="todo-action-btn" onclick="updateTodoStatus(${todo.id}, false)" title="标记为进行中">
              <i class="fas fa-undo"></i>
            </button>
          `}
          
          <button class="todo-action-btn" onclick="editTodo(${todo.id})" title="编辑">
            <i class="fas fa-edit"></i>
          </button>
          
          <button class="todo-action-btn delete" onclick="confirmDeleteTodo(${todo.id})" title="删除">
            <i class="fas fa-trash-alt"></i>
          </button>
        </div>
        
        <div class="todo-content">
          <h5 class="todo-title">${title}</h5>
          ${content ? `<p class="todo-description">${content}</p>` : ''}
          
          <div class="todo-meta">
            ${status === 'false' && dueDateStr ? `
              <span class="todo-due-date">
                <i class="fas fa-calendar-alt"></i> ${dueDateStr}
              </span>
            ` : ''}
            
            ${todo.category ? `
              <span class="todo-category">
                <i class="fas fa-folder"></i> ${escapeHtml(todo.category)}
              </span>
            ` : ''}
            
            ${todo.collaborator ? `
              <span class="todo-collaborator">
                <i class="fas fa-user-friends"></i> ${escapeHtml(todo.collaborator)}
              </span>
            ` : ''}
            
            ${todo.todo_type ? `
              <span class="todo-type">
                <i class="fas fa-tasks"></i> ${escapeHtml(todo.todo_type)}
              </span>
            ` : ''}
            
            ${status === 'true' && completedTimeStr ? `
              <span class="todo-completed-time">
                <i class="fas fa-check-circle"></i> ${completedTimeStr}
              </span>
            ` : ''}
          </div>
        </div>
      </div>
    `;
  });
  
  // 更新DOM
  listContainer.innerHTML = html;
}

/**
 * HTML转义函数，防止XSS攻击
 * @param {string} str - 需要转义的字符串
 * @returns {string} - 转义后的字符串
 */
function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * 解析自然语言文本
 */
function updateParseStatus(message, stage) {
  console.log('更新解析状态:', { message, stage }); // 调试日志
  
  const statusElement = document.getElementById('parseStatus');
  
  // 清除之前的类
  statusElement.className = 'parse-status';
  
  // 添加当前阶段的类
  if (stage) {
    statusElement.classList.add(stage);
  }
  
  // 设置消息
  statusElement.textContent = message;
  
  // 显示状态元素
  statusElement.classList.remove('hidden');
  
  // 确保parseResult容器可见
  document.getElementById('parseResult').style.display = 'block';
}

/**
 * 解析自然语言文本
 */
function parseText() {
  const text = document.getElementById('todoText').value.trim();
  
  if (!text) {
    showToast('请输入待办事项描述！');
    return;
  }
  
  console.log('开始解析文本:', text); // 调试日志
  
  // 显示解析状态
  updateParseStatus('正在连接API服务...', 'parsing');
  
  // 添加加载指示器
  document.getElementById('parseBtn').disabled = true;
  document.getElementById('parseBtn').textContent = '解析中...';

  // 不要在这里隐藏预览区域，而是在API调用成功后再处理
  
  const startTime = Date.now(); // 开始计时
  
  let timer;
  timer = setInterval(() => {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    document.getElementById('parseStatus').innerText = `解析中，已用时 ${elapsed} 秒`;
  }, 1000);

  fetch(`${API_BASE_URL}/parse`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ text })
  })
    .then(response => {
      console.log('API响应状态:', response.status); // 调试日志
      // 检查HTTP状态码
      if (!response.ok) {
        throw new Error(`HTTP错误：${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      clearInterval(timer); // 停止计时器
      const endTime = Date.now(); // 结束计时
      const duration = (endTime - startTime) / 1000; // 计算耗时
      document.getElementById('parseStatus').innerText = `解析完成，耗时 ${duration} 秒`;
      
      console.log('API响应数据:', data); // 添加调试日志
      
      if (data.success) {
        // 更新解析状态
        updateParseStatus(`解析完成，耗时 ${duration} 秒`, data.stage);
        
        // 如果解析完成，更新预览
        if (data.stage === 'completed' && data.data) {
          console.log('解析完成，准备显示预览:', data.data); // 调试日志
          
          // 保存解析数据到全局变量
          window.parsedTodoData = data.data;
          
          // 检查预览区域的状态
          const previewSection = document.getElementById('previewSection');
          console.log('预览区域显示前状态:', {
            hidden: previewSection.classList.contains('hidden'),
            active: previewSection.classList.contains('active'),
            display: previewSection.style.display,
            offsetHeight: previewSection.offsetHeight,
            offsetWidth: previewSection.offsetWidth
          });
          
          // 显示预览而不是直接更新表单
          updatePreview(data.data);
          
          // 隐藏表单部分
          document.getElementById('todoFormSection').classList.add('hidden');
          
          // 再次检查预览区域的状态
          setTimeout(() => {
            console.log('预览区域显示后状态:', {
              hidden: previewSection.classList.contains('hidden'),
              active: previewSection.classList.contains('active'),
              display: previewSection.style.display,
              offsetHeight: previewSection.offsetHeight,
              offsetWidth: previewSection.offsetWidth
            });
          }, 100);
        }
      } else {
        // 显示错误
        updateParseStatus(data.message || '解析失败，请检查API设置或网络连接', 'error');
      }
    })
    .catch(error => {
      clearInterval(timer); // 停止计时器
      console.error('解析失败:', error);
      updateParseStatus('解析请求失败，请重试！详情：' + error.message, 'error');
    })
    .finally(() => {
      // 恢复按钮状态
      document.getElementById('parseBtn').disabled = false;
      document.getElementById('parseBtn').textContent = '解析';
    });
}

/**
 * 保存待办事项
 */
function saveTodo() {
  console.log('保存待办事项...');
  
  // 获取表单数据
  const todoId = currentEditingTodoId;
  const title = document.getElementById('todoTitle').value.trim();
  const content = document.getElementById('todoContent').value.trim();
  const priority = document.getElementById('todoPriority').value;
  const dueDate = document.getElementById('todoDueDate').value;
  const category = document.getElementById('todoCategory').value.trim();
  const collaborator = document.getElementById('todoCollaborator').value.trim();
  const todoType = document.getElementById('todoType').value;
  
  // 获取原始时间描述（如果有）
  const dueDateRawInput = document.getElementById('todoDueDateRaw');
  const dueDateRaw = dueDateRawInput ? dueDateRawInput.value : '';
  
  // 表单验证
  if (!title) {
    showToast('请输入标题', 'error');
    return;
  }
  
  // 构建待办数据
  const todoData = {
    title: title,
    content: content,
    priority: priority,
    category: category,
    collaborator: collaborator,
    todo_type: todoType
  };
  
  // 处理原始时间描述
  if (dueDateRaw) {
    todoData.due_date_raw = dueDateRaw;
    
    // 如果没有due_date但有due_date_raw，尝试转换
    if (!dueDate && dueDateRaw) {
      const dueDateObj = convertTimeDescription(dueDateRaw);
      if (dueDateObj && !isNaN(dueDateObj.getTime())) {
        // 使用toISOString确保时区一致性，与confirmPreview和updatePreview保持一致
        const year = dueDateObj.getFullYear();
        const month = String(dueDateObj.getMonth() + 1).padStart(2, '0');
        const day = String(dueDateObj.getDate()).padStart(2, '0');
        const hours = String(dueDateObj.getHours()).padStart(2, '0');
        const minutes = String(dueDateObj.getMinutes()).padStart(2, '0');
        const seconds = String(dueDateObj.getSeconds()).padStart(2, '0');
        todoData.due_date = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        console.log('从原始描述转换的日期时间:', todoData.due_date, '原始描述:', dueDateRaw);
      }
    }
  }
  
  // 处理日期
  if (dueDate) {
    try {
      // 转换为datetime-local格式 (YYYY-MM-DDTHH:MM)
      let dueDateObj;
      
      // 处理不同的日期格式
      if (typeof dueDate === 'string') {
        if (dueDate.includes('T')) {
          // ISO格式
          dueDateObj = new Date(dueDate);
        } else if (dueDate.includes(' ')) {
          // 数据库格式 (YYYY-MM-DD HH:MM:SS)
          dueDateObj = new Date(dueDate.replace(' ', 'T'));
        } else {
          // 其他格式
          dueDateObj = new Date(dueDate);
        }
      } else {
        dueDateObj = new Date(dueDate);
      }
      
      if (!isNaN(dueDateObj.getTime())) {
        // 格式化为服务器需要的日期格式
        const year = dueDateObj.getFullYear();
        const month = String(dueDateObj.getMonth() + 1).padStart(2, '0');
        const day = String(dueDateObj.getDate()).padStart(2, '0');
        const hours = String(dueDateObj.getHours()).padStart(2, '0');
        const minutes = String(dueDateObj.getMinutes()).padStart(2, '0');
        const seconds = String(dueDateObj.getSeconds()).padStart(2, '0');
        
        // 添加到请求数据中
        todoData.due_date = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        
        // 添加详细日志，记录时间转换过程
        console.log('表单日期转换过程:', {
          originalDate: dueDate,
          parsedDate: dueDateObj,
          formattedForServer: todoData.due_date
        });
      } else {
        console.warn('无效的日期格式:', dueDate);
      }
    } catch (e) {
      console.error('日期处理错误:', e);
    }
  }
  
  let url = `${API_BASE_URL}/todos`;
  let method = 'POST';
  
  // 如果是编辑模式
  if (todoId) {
    url = `${API_BASE_URL}/todos/${todoId}`;
    method = 'PUT';
    // 编辑模式下不修改状态
    delete todoData.status;
  }
  
  console.log(`发送${method}请求到: ${url}`, todoData);
  
  // 显示加载状态
  document.getElementById('saveButton').disabled = true;
  document.getElementById('saveButton').textContent = '保存中...';
  
  fetch(url, {
    method: method,
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(todoData)
  })
    .then(response => {
      console.log('收到响应:', response);
      if (!response.ok) {
        throw new Error(`HTTP错误! 状态: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      console.log('保存成功，服务器返回:', data);
      
      // 关闭模态框
      closeModals();
      
      // 重置表单
      resetTodoModal();
      
      // 显示成功消息
      showToast(todoId ? '待办事项已更新' : '待办事项已创建', 'success');
      
      // 重新加载待办事项列表
      loadTodos('false');
      loadTodos('true');
    })
    .catch(error => {
      console.error('保存待办事项时出错:', error);
      showToast(`保存失败: ${error.message}`, 'error');
    })
    .finally(() => {
      // 恢复按钮状态
      document.getElementById('saveButton').disabled = false;
      document.getElementById('saveButton').textContent = '保存';
    });
}

/**
 * 编辑待办事项
 * @param {string} todoId - 待办事项ID
 */
function editTodo(todoId) {
  fetch(`${API_BASE_URL}/todos/${todoId}`)
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP错误! 状态: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      console.log('获取待办事项响应:', data); // 添加调试日志
      
      if (data.success && data.todo) {
        const todo = data.todo;
        
        // 检查todo是否有效
        if (!todo || typeof todo !== 'object') {
          throw new Error('服务器返回的待办数据无效');
        }
        
        // 设置当前编辑的待办ID
        currentEditingTodoId = todoId;
        
        // 更新表单
        updateTodoForm(todo);
        
        // 更新模态框标题
        document.getElementById('todoModalTitle').textContent = '编辑待办事项';
        
        // 显示模态框
        openModal('todoModal');
      } else {
        showToast(`获取待办事项失败: ${data.message || '未知错误'}`, 'error');
      }
    })
    .catch(error => {
      console.error('编辑待办事项失败:', error);
      showToast(`编辑失败: ${error.message}`, 'error');
    });
}

/**
 * 确认删除待办事项
 * @param {string} todoId - 待办事项ID
 */
function confirmDeleteTodo(todoId) {
  deletingTodoId = todoId;
  openModal('confirmDeleteModal');
}

/**
 * 删除待办事项
 * @param {string} todoId - 待办事项ID
 */
function deleteTodo(todoId) {
  if (!todoId) return;
  
  fetch(`${API_BASE_URL}/todos/${todoId}`, {
    method: 'DELETE'
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        closeModals();
        // 重新加载待办列表
        loadTodos('false');
        loadTodos('true');
        showToast('待办事项已删除！');
      } else {
        showToast(`删除失败: ${data.message || '未知错误'}`);
      }
    })
    .catch(error => {
      console.error('删除待办事项失败:', error);
      showToast('删除失败，请重试！');
    });
}

/**
 * 完成待办事项
 * @param {string} todoId - 待办事项ID
 */
function completeTodo(todoId) {
  updateTodoStatus(todoId, true);
}

/**
 * 撤销完成待办事项
 * @param {string} todoId - 待办事项ID
 */
function undoTodo(todoId) {
  updateTodoStatus(todoId, false);
}

/**
 * 更新待办事项状态
 * @param {string} todoId - 待办事项ID
 * @param {boolean} status - 状态（true=已完成, false=进行中）
 */
function updateTodoStatus(todoId, status) {
  console.log(`更新待办事项状态: ID=${todoId}, 状态=${status ? '已完成' : '进行中'}`);
  
  // 显示加载状态
  const todoCard = document.querySelector(`.todo-card[data-id="${todoId}"]`);
  if (todoCard) {
    // 添加加载状态样式
    todoCard.classList.add('updating');
    
    // 禁用按钮
    const buttons = todoCard.querySelectorAll('button');
    buttons.forEach(btn => btn.disabled = true);
  }
  
  // 构建请求数据
  const requestData = { status: status };
  
  // 发起API请求
  fetch(`${API_BASE_URL}/todos/${todoId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(requestData)
  })
    .then(response => {
      console.log(`状态更新响应: ${response.status} ${response.statusText}`);
      if (!response.ok) {
        throw new Error(`HTTP错误! 状态: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      console.log('状态更新成功，服务器返回:', data);
      
      if (data.success) {
        // 显示成功消息
        showToast(status ? '待办事项已标记为完成' : '待办事项已恢复为进行中', 'success');
        
        // 移除加载状态
        if (todoCard) {
          todoCard.classList.remove('updating');
          buttons.forEach(btn => btn.disabled = false);
        }
        
        // 重新加载待办列表
        setTimeout(() => {
          loadTodos('false');
          loadTodos('true', getCurrentDateFilter());
        }, 300);
      } else {
        throw new Error(data.message || '操作失败');
      }
    })
    .catch(error => {
      console.error('更新待办事项状态失败:', error);
      showToast(`操作失败: ${error.message}`, 'error');
      
      // 移除加载状态
      if (todoCard) {
        todoCard.classList.remove('updating');
        buttons.forEach(btn => btn.disabled = false);
      }
    });
}

/**
 * 更新待办表单
 * @param {Object} todoData - 待办数据
 */
function updateTodoForm(todoData) {
  console.log('更新表单数据:', todoData); // 添加调试日志
  
  try {
    // 检查todoData是否为undefined或null
    if (!todoData) {
      console.error('待办数据为空');
      showToast('无法加载待办数据', 'error');
      return;
    }
    
    // 处理可能的字符串JSON
    let data = todoData;
    if (typeof todoData === 'string') {
      try {
        data = JSON.parse(todoData);
      } catch (e) {
        console.error('JSON解析失败:', e);
      }
    }
    
    // 显示表单部分
    document.getElementById('todoFormSection').classList.remove('hidden');
    
    // 更新表单字段
    document.getElementById('todoTitle').value = data.title || '';
    document.getElementById('todoContent').value = data.content || '';
    
    // 设置优先级
    const prioritySelect = document.getElementById('todoPriority');
    if (data.priority) {
      // 查找匹配的选项
      for (let i = 0; i < prioritySelect.options.length; i++) {
        if (prioritySelect.options[i].value === data.priority) {
          prioritySelect.selectedIndex = i;
          break;
        }
      }
    }
    
    // 设置分类
    document.getElementById('todoCategory').value = data.category || '';
    
    // 设置协作方
    document.getElementById('todoCollaborator').value = data.collaborator || '';
    
    // 设置待办类型
    const todoTypeSelect = document.getElementById('todoType');
    if (data.todo_type) {
      // 查找匹配的选项
      for (let i = 0; i < todoTypeSelect.options.length; i++) {
        if (todoTypeSelect.options[i].value === data.todo_type) {
          todoTypeSelect.selectedIndex = i;
          break;
        }
      }
    } else {
      todoTypeSelect.selectedIndex = 0; // 默认选择第一项
    }
    
    // 处理原始时间描述
    if (data.due_date_raw) {
      // 存储原始时间描述到隐藏字段
      const dueDateRawInput = document.getElementById('todoDueDateRaw');
      if (dueDateRawInput) {
        dueDateRawInput.value = data.due_date_raw;
      } else {
        // 如果不存在，创建一个隐藏的输入字段
        const hiddenInput = document.createElement('input');
        hiddenInput.type = 'hidden';
        hiddenInput.id = 'todoDueDateRaw';
        hiddenInput.name = 'todoDueDateRaw';
        hiddenInput.value = data.due_date_raw;
        document.getElementById('todoForm').appendChild(hiddenInput);
      }
      
      // 如果没有due_date但有due_date_raw，尝试转换
      if (!data.due_date && data.due_date_raw) {
        const dueDate = convertTimeDescription(data.due_date_raw);
        if (dueDate && !isNaN(dueDate.getTime())) {
          // 使用toISOString确保时区一致性，与confirmPreview和updatePreview保持一致
          const year = dueDate.getFullYear();
          const month = String(dueDate.getMonth() + 1).padStart(2, '0');
          const day = String(dueDate.getDate()).padStart(2, '0');
          const hours = String(dueDate.getHours()).padStart(2, '0');
          const minutes = String(dueDate.getMinutes()).padStart(2, '0');
          const seconds = String(dueDate.getSeconds()).padStart(2, '0');
          data.due_date = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
          console.log('转换后的日期时间:', data.due_date, '原始描述:', data.due_date_raw);
        }
      }
    }
    
    // 处理日期
    if (data.due_date) {
      try {
        // 转换为datetime-local格式 (YYYY-MM-DDTHH:MM)
        let dueDate;
        
        // 处理不同的日期格式
        if (typeof data.due_date === 'string') {
          if (data.due_date.includes('T')) {
            // ISO格式
            dueDate = new Date(data.due_date);
          } else if (data.due_date.includes(' ')) {
            // 数据库格式 (YYYY-MM-DD HH:MM:SS)
            dueDate = new Date(data.due_date.replace(' ', 'T'));
          } else {
            // 其他格式
            dueDate = new Date(data.due_date);
          }
        } else {
          dueDate = new Date(data.due_date);
        }
        
        if (!isNaN(dueDate.getTime())) {
          // 格式化为HTML datetime-local输入所需的格式
          const year = dueDate.getFullYear();
          const month = String(dueDate.getMonth() + 1).padStart(2, '0');
          const day = String(dueDate.getDate()).padStart(2, '0');
          const hours = String(dueDate.getHours()).padStart(2, '0');
          const minutes = String(dueDate.getMinutes()).padStart(2, '0');
          
          const localDateString = `${year}-${month}-${day}T${hours}:${minutes}`;
          document.getElementById('todoDueDate').value = localDateString;
          
          // 添加详细日志，记录时间转换过程
          console.log('表单日期转换过程:', {
            originalDate: data.due_date,
            parsedDate: dueDate,
            formattedForInput: localDateString,
            isoString: dueDate.toISOString().slice(0, 19).replace('T', ' ')
          });
        } else {
          document.getElementById('todoDueDate').value = '';
          console.warn('无效的日期格式:', data.due_date);
        }
      } catch (e) {
        console.error('日期处理错误:', e);
      }
    } else {
      document.getElementById('todoDueDate').value = '';
    }
    
  } catch (error) {
    console.error('更新表单时出错:', error);
    showToast('更新表单时出错', 'error');
  }
}

/**
 * 预览确认
 */
function confirmPreview() {
  try {
    // 如果已经在保存中，则不再处理
    if (isSavingTodo) {
      console.log('已经在保存中，请勿重复操作');
      return;
    }
    
    // 获取预览区域的数据
    const title = document.getElementById('previewTitle').textContent;
    const content = document.getElementById('previewContent').textContent;
    const priority = document.getElementById('previewPriority').textContent;
    const dateText = document.getElementById('previewDate').textContent;
    const dateRaw = document.getElementById('previewDate').getAttribute('data-raw');
    const dateIso = document.getElementById('previewDate').getAttribute('data-iso'); // 获取ISO格式的日期
    const collaborator = document.getElementById('previewCollaborator').textContent;
    const todoType = document.getElementById('previewType').textContent;
    
    // 创建待办数据对象
    const todoData = {
      title: title,
      content: content,
      priority: priority,
      category: '', // 默认空分类
      due_date: dateIso || '', // 直接使用ISO格式的日期
      due_date_raw: dateRaw || '',
      collaborator: collaborator === '无协作方' ? '' : collaborator,
      todo_type: todoType === '未指定类型' ? '' : todoType
    };
    
    console.log('确认使用预览数据并直接保存:', todoData);
    
    // 设置保存标志
    isSavingTodo = true;
    
    // 隐藏预览区域
    const previewSection = document.getElementById('previewSection');
    previewSection.classList.remove('active');
    
    // 等待动画完成后隐藏并保存
    setTimeout(() => {
      previewSection.classList.add('hidden');
      
      // 直接调用保存API
      fetch(`${API_BASE_URL}/todos`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(todoData)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP错误! 状态: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        if (data.success) {
          // 显示成功消息
          showToast('待办事项已保存！');
          
          // 关闭模态框
          closeModals();
          
          // 重置待办模态框
          resetTodoModal();
          
          // 重新加载待办列表
          loadTodos('false');
        } else {
          throw new Error(data.message || '保存失败');
        }
      })
      .catch(error => {
        console.error('保存待办事项失败:', error);
        showToast(`保存失败: ${error.message}`, 'error');
      })
      .finally(() => {
        // 重置保存状态
        isSavingTodo = false;
      });
      
    }, 300);
    
  } catch (error) {
    console.error('确认预览时出错:', error);
    showToast('处理预览数据时出错', 'error');
    isSavingTodo = false; // 重置保存标志
  }
}

/**
 * 预览编辑
 */
function editPreview() {
  try {
    // 获取预览区域的数据
    const title = document.getElementById('previewTitle').textContent;
    const content = document.getElementById('previewContent').textContent;
    const priority = document.getElementById('previewPriority').textContent;
    const dateText = document.getElementById('previewDate').textContent;
    const dateRaw = document.getElementById('previewDate').getAttribute('data-raw');
    const dateIso = document.getElementById('previewDate').getAttribute('data-iso'); // 获取ISO格式的日期
    const collaborator = document.getElementById('previewCollaborator').textContent;
    const todoType = document.getElementById('previewType').textContent;
    
    // 创建待办数据对象
    const todoData = {
      title: title,
      content: content,
      priority: priority,
      category: '', // 默认空分类
      due_date: dateIso || '', // 直接使用ISO格式的日期
      due_date_raw: dateRaw || '',
      collaborator: collaborator === '无协作方' ? '' : collaborator,
      todo_type: todoType === '未指定类型' ? '' : todoType
    };
    
    console.log('编辑预览数据:', todoData);
    
    // 隐藏预览区域并显示动画
    const previewSection = document.getElementById('previewSection');
    previewSection.classList.remove('active');
    
    // 等待动画完成后隐藏
    setTimeout(() => {
      previewSection.classList.add('hidden');
      
      // 更新表单数据并显示表单
      updateTodoForm(todoData);
      
      // 显示提示
      showToast('请编辑待办信息', 'info');
    }, 300);
    
  } catch (error) {
    console.error('编辑预览时出错:', error);
    showToast('处理预览数据时出错', 'error');
  }
}

/**
 * 更新预览
 * @param {Object} data - 预览数据
 */
function updatePreview(data) {
  console.log('更新预览数据:', data); // 调试日志
  
  try {
    // 获取预览区域元素
    const previewSection = document.getElementById('previewSection');
    const previewTitle = document.getElementById('previewTitle');
    const previewPriority = document.getElementById('previewPriority');
    const previewContent = document.getElementById('previewContent');
    const previewDate = document.getElementById('previewDate');
    const previewType = document.getElementById('previewType');
    const previewCollaborator = document.getElementById('previewCollaborator');
    
    // 处理可能的字符串JSON
    let parsedData = data;
    if (typeof data === 'string') {
      try {
        parsedData = JSON.parse(data);
      } catch (e) {
        console.error('JSON解析失败:', e);
      }
    }
    
    // 设置预览内容
    previewTitle.textContent = parsedData.title || '新建待办';
    previewContent.textContent = parsedData.content || '无详细内容';
    
    // 设置优先级样式
    previewPriority.textContent = parsedData.priority || '中';
    previewPriority.className = 'preview-priority';
    
    // 根据优先级添加对应的样式类
    if (parsedData.priority === '高') {
      previewPriority.classList.add('high');
    } else if (parsedData.priority === '中') {
      previewPriority.classList.add('medium');
    } else {
      previewPriority.classList.add('low');
    }
    
    // 设置待办事项类型
    if (parsedData.todo_type) {
      previewType.textContent = parsedData.todo_type;
      previewType.parentElement.style.display = 'flex';
    } else {
      previewType.textContent = '未指定类型';
      previewType.parentElement.style.display = 'none';
    }
    
    // 设置协作方
    if (parsedData.collaborator) {
      previewCollaborator.textContent = parsedData.collaborator;
      previewCollaborator.parentElement.style.display = 'flex';
    } else {
      previewCollaborator.textContent = '无协作方';
      previewCollaborator.parentElement.style.display = 'none';
    }
    
    // 格式化并显示截止日期
    if (parsedData.due_date_raw) {
      const dueDate = convertTimeDescription(parsedData.due_date_raw);
      if (dueDate) {
        // 使用toLocaleDateString格式化显示，但在data属性中保存ISO格式
        const formattedDate = dueDate.toLocaleDateString('zh-CN', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
        
        // 生成ISO格式的日期字符串用于保存
        const year = dueDate.getFullYear();
        const month = String(dueDate.getMonth() + 1).padStart(2, '0');
        const day = String(dueDate.getDate()).padStart(2, '0');
        const hours = String(dueDate.getHours()).padStart(2, '0');
        const minutes = String(dueDate.getMinutes()).padStart(2, '0');
        const seconds = String(dueDate.getSeconds()).padStart(2, '0');
        const isoDateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        
        // 设置显示文本和数据属性
        previewDate.textContent = formattedDate;
        previewDate.setAttribute('data-raw', parsedData.due_date_raw);
        previewDate.setAttribute('data-iso', isoDateString); // 添加ISO格式日期作为属性
        
        console.log('预览日期转换:', {
          raw: parsedData.due_date_raw,
          date: dueDate,
          formatted: formattedDate,
          isoFormat: isoDateString
        });
      } else {
        previewDate.textContent = '无法解析日期';
        previewDate.removeAttribute('data-raw');
        previewDate.removeAttribute('data-iso');
      }
    } else {
      previewDate.textContent = '无截止日期';
      previewDate.removeAttribute('data-raw');
      previewDate.removeAttribute('data-iso');
    }
    
    console.log('预览区域状态 - 开始:', {
      hidden: previewSection.classList.contains('hidden'),
      active: previewSection.classList.contains('active'),
      display: previewSection.style.display
    });
    
    // 确保parseResult容器可见
    const parseResult = document.getElementById('parseResult');
    parseResult.style.display = 'block';
    
    // 隐藏解析状态，显示预览区域
    document.getElementById('parseStatus').classList.add('hidden');
    
    // 重置预览区域状态
    previewSection.classList.remove('active');
    
    // 确保预览区域可见
    previewSection.style.display = 'block';
    previewSection.classList.remove('hidden');
    
    console.log('预览区域状态 - 移除hidden后:', {
      hidden: previewSection.classList.contains('hidden'),
      active: previewSection.classList.contains('active'),
      display: previewSection.style.display
    });
    
    // 使用setTimeout确保DOM更新后再添加动画类
    setTimeout(() => {
      previewSection.classList.add('active');
      
      console.log('预览区域状态 - 添加active后:', {
        hidden: previewSection.classList.contains('hidden'),
        active: previewSection.classList.contains('active'),
        display: previewSection.style.display
      });
      
      // 滚动到预览区域
      previewSection.scrollIntoView({ behavior: 'smooth' });
    }, 50); // 增加延迟时间，确保DOM已更新
    
    // 隐藏表单区域
    document.getElementById('todoFormSection').classList.add('hidden');
    
    // 添加预览区域的确认和编辑按钮事件监听器
    document.getElementById('confirmPreviewBtn').onclick = confirmPreview;
    document.getElementById('editPreviewBtn').onclick = editPreview;
    
  } catch (error) {
    console.error('更新预览时出错:', error);
    showToast('无法显示预览，请重试');
  }
}

/**
 * 获取当前日期筛选值
 */
function getCurrentDateFilter() {
  const dateInput = document.getElementById('completedDateFilter');
  return dateInput && dateInput.value ? dateInput.value : null;
}

/**
 * 应用日期筛选
 */
function applyDateFilter() {
  const dateInput = document.getElementById('completedDateFilter');
  if (dateInput && dateInput.value) {
    console.log(`应用日期筛选: ${dateInput.value}`);
    
    // 加载筛选后的待办事项
    loadTodos('true', dateInput.value);
    
    // 显示成功消息
    showToast(`已筛选 ${dateInput.value} 完成的待办事项`, 'info');
  } else {
    showToast('请先选择日期', 'warning');
  }
}

/**
 * 清除日期筛选
 */
function clearDateFilter() {
  const dateInput = document.getElementById('completedDateFilter');
  if (dateInput) {
    dateInput.value = '';
  }
  
  // 重新加载所有已完成的待办事项
  loadTodos('true');
  
  // 显示消息
  showToast('已清除日期筛选', 'info');
}

/**
 * 打开新建待办事项模态框
 */
function openNewTodoModal() {
  resetTodoModal();
  openModal('todoModal');
}
