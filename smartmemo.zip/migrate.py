from app import app, db
import sqlite3
import os

with app.app_context():
    # 创建或更新表结构
    db.create_all()
    
    # 获取数据库文件路径
    db_files = ['instance/todo.db', 'instance/smart_memo.db']
    
    for db_file in db_files:
        if not os.path.exists(db_file):
            print(f"数据库文件 {db_file} 不存在，跳过")
            continue
            
        print(f"处理数据库文件: {db_file}")
        
        # 手动添加due_date_raw列（如果不存在）
        try:
            conn = sqlite3.connect(db_file)
            cursor = conn.cursor()
            
            # 检查todo表是否存在
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='todo'")
            if not cursor.fetchone():
                print(f"数据库 {db_file} 中不存在todo表，跳过")
                conn.close()
                continue
            
            # 检查列是否存在
            cursor.execute("PRAGMA table_info(todo)")
            columns = [column[1] for column in cursor.fetchall()]
            
            if 'due_date_raw' not in columns:
                print(f"在 {db_file} 中添加due_date_raw列...")
                cursor.execute("ALTER TABLE todo ADD COLUMN due_date_raw TEXT")
                conn.commit()
                print(f"due_date_raw列添加成功到 {db_file}！")
            else:
                print(f"due_date_raw列已存在于 {db_file}，无需添加")
                
            conn.close()
        except Exception as e:
            print(f"处理 {db_file} 时出错: {e}")
    
    print("数据库迁移完成！")
