"""
智能备忘录应用主文件
提供Web服务和API接口
"""
# 应用版本号
APP_VERSION = "1.0.4"

import os
import json
import requests
from flask import Flask, render_template, request, jsonify, flash, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_cors import CORS

# 导入配置
from config import Config

# 创建应用
app = Flask(__name__)
CORS(app)  # 启用CORS支持，允许跨域请求
app.config.from_object(Config)

# 初始化数据库
db = SQLAlchemy(app)

# 模型定义
class Todo(db.Model):
    """待办事项模型"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=True)
    due_date = db.Column(db.DateTime, nullable=True)
    due_date_raw = db.Column(db.String(100), nullable=True)
    priority = db.Column(db.String(20), default='中')  # 低、中、高
    category = db.Column(db.String(50), nullable=True)  # 分类
    collaborator = db.Column(db.String(100), nullable=True)  # 协作方
    todo_type = db.Column(db.String(50), nullable=True)  # 待办事项类型
    status = db.Column(db.Boolean, default=False)  # False=未完成, True=已完成
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, nullable=True)
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'due_date': self.due_date.strftime('%Y-%m-%d %H:%M:%S') if self.due_date else None,
            'due_date_raw': self.due_date_raw,
            'priority': self.priority,
            'category': self.category,
            'collaborator': self.collaborator,
            'todo_type': self.todo_type,
            'status': self.status,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None
        }

class Setting(db.Model):
    """设置模型"""
    id = db.Column(db.Integer, primary_key=True)
    model_name = db.Column(db.String(100), nullable=False, default='')
    api_key = db.Column(db.String(100), nullable=False, default='')
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'model_name': self.model_name,
            'api_key': self.api_key
        }

# 确保数据库表已创建
with app.app_context():
    db.create_all()
    # 确保有一个设置记录
    if not Setting.query.first():
        default_setting = Setting()
        db.session.add(default_setting)
        db.session.commit()

# 路由
@app.route('/')
def index():
    """首页"""
    return render_template('index.html', version=APP_VERSION)

@app.route('/api/settings', methods=['GET'])
def get_settings():
    """获取设置信息"""
    setting = Setting.query.first()
    if not setting:
        setting = Setting()
        db.session.add(setting)
        db.session.commit()
    
    return jsonify({'success': True, 'data': setting.to_dict()})

@app.route('/api/version', methods=['GET'])
def get_version():
    """获取应用版本号"""
    return jsonify({"version": APP_VERSION})

@app.route('/api/settings', methods=['POST'])
def update_settings():
    """更新设置信息"""
    data = request.json
    setting = Setting.query.first()
    
    if not setting:
        setting = Setting()
        db.session.add(setting)
    
    setting.model_name = data.get('model_name', '')
    setting.api_key = data.get('api_key', '')
    
    db.session.commit()
    
    return jsonify({'success': True, 'data': setting.to_dict()})

@app.route('/api/todos', methods=['GET', 'POST'])
def handle_todos():
    if request.method == 'GET':
        try:
            # 获取查询参数
            status = request.args.get('status', 'false')
            is_completed = status.lower() == 'true'
            
            # 获取日期筛选参数
            date_filter = request.args.get('date', None)
            
            # 构建基础查询
            query = Todo.query.filter_by(status=is_completed)
            
            # 如果有日期筛选参数，添加日期过滤条件
            if date_filter and is_completed:
                try:
                    # 解析日期字符串为datetime对象
                    filter_date = datetime.strptime(date_filter, '%Y-%m-%d')
                    
                    # 创建当天开始和结束的时间范围
                    start_of_day = datetime(filter_date.year, filter_date.month, filter_date.day, 0, 0, 0)
                    end_of_day = datetime(filter_date.year, filter_date.month, filter_date.day, 23, 59, 59)
                    
                    # 根据updated_at字段筛选
                    query = query.filter(Todo.updated_at >= start_of_day, Todo.updated_at <= end_of_day)
                    
                    app.logger.info(f"应用日期筛选: {date_filter}")
                except ValueError:
                    app.logger.warning(f"无效的日期格式: {date_filter}")
            
            # 排序：已完成的按更新时间降序，进行中的按创建时间降序
            if is_completed:
                todos = query.order_by(Todo.updated_at.desc()).all()
            else:
                todos = query.order_by(Todo.created_at.desc()).all()
            
            # 转换为字典列表
            todo_list = [todo.to_dict() for todo in todos]
            
            # 记录日志
            app.logger.info(f"获取待办事项成功，状态: {status}, 日期筛选: {date_filter}, 数量: {len(todo_list)}")
            
            return jsonify({'success': True, 'data': todo_list})
        except Exception as e:
            app.logger.error(f"获取待办事项失败: {str(e)}")
            return jsonify({'success': False, 'message': str(e)}), 500
    
    elif request.method == 'POST':
        try:
            # 获取JSON数据
            data = request.get_json()
            
            # 验证必填字段
            if not data.get('title'):
                return jsonify({
                    'success': False,
                    'message': '标题不能为空'
                }), 400
            
            # 创建新的待办事项
            new_todo = Todo(
                title=data.get('title'),
                content=data.get('content', ''),
                category=data.get('category', ''),
                priority=data.get('priority', '中'),
                status=data.get('status', False),
                due_date_raw=data.get('due_date_raw', ''),
                collaborator=data.get('collaborator', ''),
                todo_type=data.get('todo_type', '')
            )
            
            # 处理日期
            if data.get('due_date'):
                try:
                    # 尝试多种日期格式
                    date_formats = [
                        '%Y-%m-%d %H:%M:%S',  # 2023-01-01 12:00:00
                        '%Y-%m-%dT%H:%M:%S',  # 2023-01-01T12:00:00
                        '%Y-%m-%d',           # 2023-01-01
                    ]
                    
                    due_date = None
                    for fmt in date_formats:
                        try:
                            due_date = datetime.strptime(data.get('due_date'), fmt)
                            break
                        except ValueError:
                            continue
                    
                    if due_date:
                        new_todo.due_date = due_date
                    else:
                        app.logger.warning(f"无法解析日期: {data.get('due_date')}")
                except Exception as e:
                    app.logger.warning(f"解析日期时出错: {str(e)}")
            
            # 保存到数据库
            db.session.add(new_todo)
            db.session.commit()
            
            # 返回新创建的待办事项
            return jsonify({
                'success': True,
                'message': '待办事项创建成功',
                'todo': new_todo.to_dict()
            }), 201
        
        except Exception as e:
            # 回滚事务
            db.session.rollback()
            app.logger.error(f"创建待办事项失败: {str(e)}")
            return jsonify({
                'success': False,
                'message': f"创建待办事项失败: {str(e)}"
            }), 500

@app.route('/api/todos/<int:todo_id>', methods=['GET', 'PUT', 'DELETE'])
def handle_todo(todo_id):
    """处理单个待办事项的获取、更新和删除"""
    # 查找待办事项
    todo = Todo.query.get(todo_id)
    if not todo:
        return jsonify({
            'success': False,
            'message': f'找不到ID为{todo_id}的待办事项'
        }), 404
    
    if request.method == 'GET':
        # 获取待办事项详情
        return jsonify({
            'success': True,
            'todo': todo.to_dict()
        })
    
    elif request.method == 'PUT':
        try:
            # 获取JSON数据
            data = request.get_json()
            
            # 更新待办事项
            if 'title' in data:
                todo.title = data['title']
            
            if 'content' in data:
                todo.content = data['content']
            
            if 'priority' in data:
                todo.priority = data['priority']
            
            if 'category' in data:
                todo.category = data['category']
            
            # 处理状态更新 - 记录完成时间
            if 'status' in data:
                # 如果状态从未完成变为已完成，记录完成时间
                if data['status'] == True and todo.status == False:
                    todo.updated_at = datetime.now()
                    app.logger.info(f"待办事项 {todo_id} 标记为已完成，完成时间: {todo.updated_at}")
                todo.status = data['status']
            
            # 处理原始时间描述
            if 'due_date_raw' in data:
                todo.due_date_raw = data['due_date_raw']
            
            if 'due_date' in data:
                if data['due_date']:
                    try:
                        # 尝试多种日期格式
                        date_formats = [
                            '%Y-%m-%d %H:%M:%S',  # 2023-01-01 12:00:00
                            '%Y-%m-%dT%H:%M:%S',  # 2023-01-01T12:00:00
                            '%Y-%m-%d',           # 2023-01-01
                        ]
                        
                        due_date = None
                        for fmt in date_formats:
                            try:
                                due_date = datetime.strptime(data['due_date'], fmt)
                                break
                            except ValueError:
                                continue
                        
                        if due_date:
                            todo.due_date = due_date
                    except Exception as e:
                        app.logger.warning(f"解析日期时出错: {str(e)}")
                else:
                    todo.due_date = None
            
            if 'collaborator' in data:
                todo.collaborator = data['collaborator']
            
            if 'todo_type' in data:
                todo.todo_type = data['todo_type']
            
            # 更新时间戳 - 仅在非状态更新时更新
            if 'status' not in data:
                todo.updated_at = datetime.now()
            
            # 保存到数据库
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': '待办事项更新成功',
                'todo': todo.to_dict()
            })
        
        except Exception as e:
            # 回滚事务
            db.session.rollback()
            app.logger.error(f"更新待办事项失败: {str(e)}")
            return jsonify({
                'success': False,
                'message': f"更新待办事项失败: {str(e)}"
            }), 500
    
    elif request.method == 'DELETE':
        try:
            # 删除待办事项
            db.session.delete(todo)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': '待办事项删除成功'
            })
        
        except Exception as e:
            # 回滚事务
            db.session.rollback()
            app.logger.error(f"删除待办事项失败: {str(e)}")
            return jsonify({
                'success': False,
                'message': f"删除待办事项失败: {str(e)}"
            }), 500

@app.route('/api/parse', methods=['POST'])
def parse_text():
    """解析自然语言"""
    data = request.json
    text = data.get('text', '')
    
    # 获取设置
    setting = Setting.query.first()
    if not setting or not setting.model_name or not setting.api_key:
        return jsonify({
            'success': False, 
            'message': '请先完成API设置',
            'stage': 'error'
        })
    
    try:
        # API请求数据
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {setting.api_key}'
        }
        
        payload = {
            'model': setting.model_name,
            'messages': [
                {
                    'role': 'system',
                    'content': """你是一个专业的待办事项解析助手，擅长将自然语言转换为结构化数据。你的任务是将用户的输入精确解析为标准格式的待办事项。

请严格按照以下规则进行解析：

1. 从用户输入中提取以下关键信息：
   - 标题：简短描述待办事项的主要内容（必需）
   - 详细内容：对待办事项的详细描述（可选）
   - 截止日期：任务的截止时间（如果提到）
   - 优先级：高/中/低（如果提到，默认为"中"）
   - 分类：待办事项的分类（如果提到）
   - 协作方：需要一起完成任务的人员或部门（如果提到）
   - 待办事项类型：如会议、任务、提醒、学习等（如果提到）

2. 日期和时间处理规则：
   - 不要将日期转换为具体格式，而是提供两个字段：
     - due_date_raw: 用户原始提到的时间表述（如"明天下午3点"、"下周一早上"等）
     - due_date: 设置为null，前端会处理转换
   - 如果没有提到日期，due_date_raw和due_date都设为null

3. 优先级处理规则：
   - 明确提到"高优先级"、"紧急"等词语时，设为"高"
   - 明确提到"低优先级"、"不急"等词语时，设为"低"
   - 如果没有明确提到优先级，默认设为"中"

4. 协作方处理规则：
   - 识别"和xxx一起"、"与xxx协作"、"通知xxx"等表达
   - 如果有多个协作方，用逗号分隔
   - 如果没有提到协作方，设为null

5. 待办事项类型处理规则：
   - 根据内容识别类型，如"会议"、"任务"、"提醒"、"学习"等
   - 如果无法确定类型，可以根据内容推断一个合适的类型
   - 如果实在无法确定，设为null

6. 输出格式要求：
   - 必须以JSON格式返回
   - 必须包含title, content, due_date, due_date_raw, priority, category, collaborator, todo_type八个字段
   - 字段名必须完全匹配，不能有拼写错误
   - 不要添加任何额外的字段
   - 不要在JSON外添加任何解释性文字

输出示例：
{
    "title": "项目会议",
    "content": "讨论新功能开发计划",
    "due_date": null,
    "due_date_raw": "明天下午两点",
    "priority": "高",
    "category": "工作",
    "collaborator": "张三,李四",
    "todo_type": "会议"
}

或者：
{
    "title": "购买生日礼物",
    "content": "为妈妈挑选一本书",
    "due_date": null,
    "due_date_raw": null,
    "priority": "中",
    "category": "个人",
    "collaborator": null,
    "todo_type": "购物"
}

请记住：只返回JSON格式的数据，不要有任何其他内容。"""
                },
                {
                    'role': 'user',
                    'content': text
                }
            ],
            'temperature': 0.3
        }
        
        # 调用API
        try:
            response = requests.post(
                app.config['AI_API_ENDPOINT'],
                headers=headers,
                json=payload,
                timeout=30  # 添加超时设置
            )
            
            if response.status_code != 200:
                return jsonify({
                    'success': False,
                    'stage': 'error',
                    'message': f'API请求失败: {response.status_code}'
                })
            
            # 解析SiliconFlow API的响应
            result = response.json()
            
            # 调试信息
            app.logger.debug(f"API响应: {result}")
            app.logger.debug(f"API响应状态码: {response.status_code}")
            
            # SiliconFlow API的响应格式
            ai_response = result.get('choices', [{}])[0].get('message', {}).get('content', '')
            
            if not ai_response:
                # 如果无法获取content字段，尝试其他可能的路径
                ai_response = result.get('choices', [{}])[0].get('text', '')
                
            app.logger.debug(f"AI响应内容: {ai_response}")
                
            # 尝试清理和解析返回的JSON
            try:
                # 移除可能的额外字符如反引号、换行符等
                cleaned_response = ai_response.strip()
                
                # 如果响应被包裹在```json和```之间，提取JSON部分
                if cleaned_response.startswith('```json'):
                    cleaned_response = cleaned_response.replace('```json', '', 1)
                    if '```' in cleaned_response:
                        cleaned_response = cleaned_response.split('```')[0]
                elif cleaned_response.startswith('```'):
                    cleaned_response = cleaned_response.replace('```', '', 1)
                    if '```' in cleaned_response:
                        cleaned_response = cleaned_response.split('```')[0]
                
                cleaned_response = cleaned_response.strip()
                app.logger.debug(f"清理后的响应: {cleaned_response}")
                
                try:
                    # 尝试直接解析
                    parsed_todo = json.loads(cleaned_response)
                except json.JSONDecodeError:
                    # 如果直接解析失败，检查是否有前缀或后缀文本
                    # 查找第一个{和最后一个}
                    start_idx = cleaned_response.find('{')
                    end_idx = cleaned_response.rfind('}')
                    
                    if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
                        json_str = cleaned_response[start_idx:end_idx+1]
                        app.logger.debug(f"提取的JSON字符串: {json_str}")
                        parsed_todo = json.loads(json_str)
                    else:
                        # 尝试使用正则表达式提取JSON
                        import re
                        json_pattern = re.compile(r'\{.*\}', re.DOTALL)
                        match = json_pattern.search(cleaned_response)
                        if match:
                            json_str = match.group(0)
                            app.logger.debug(f"正则提取的JSON字符串: {json_str}")
                            parsed_todo = json.loads(json_str)
                        else:
                            # 如果仍然无法解析，返回错误
                            raise json.JSONDecodeError("无法找到有效的JSON", cleaned_response, 0)
                
                # 验证解析结果是否包含所需字段
                app.logger.debug(f"解析后的待办数据: {parsed_todo}")
                
                # 确保关键字段存在
                if not parsed_todo.get('title'):
                    parsed_todo['title'] = '新建待办'
                
                # 处理日期格式
                if parsed_todo.get('due_date'):
                    try:
                        # 尝试解析日期格式
                        datetime.strptime(parsed_todo['due_date'], '%Y-%m-%d %H:%M:%S')
                    except ValueError:
                        # 如果格式不正确，尝试其他常见格式
                        try:
                            # 尝试ISO格式
                            dt = datetime.fromisoformat(parsed_todo['due_date'].replace('Z', '+00:00'))
                            parsed_todo['due_date'] = dt.strftime('%Y-%m-%d %H:%M:%S')
                        except ValueError:
                            # 如果仍然失败，设置为null
                            app.logger.warning(f"无法解析日期: {parsed_todo['due_date']}")
                            parsed_todo['due_date'] = None
                
                # 返回成功结果
                return jsonify({
                    'success': True,
                    'stage': 'completed',
                    'message': '解析完成',
                    'data': parsed_todo
                })
                
            except json.JSONDecodeError as e:
                return jsonify({
                    'success': False,
                    'stage': 'error',
                    'message': f'无法解析AI返回的结果: {str(e)}。原始响应: {ai_response[:100]}...'
                })
        
        except requests.RequestException as e:
            return jsonify({
                'success': False,
                'stage': 'error',
                'message': f'API连接失败: {str(e)}'
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'stage': 'error',
            'message': f'处理过程中出错: {str(e)}'
        })

if __name__ == '__main__':
    # 创建数据库表
    with app.app_context():
        db.create_all()
    
    # 启动应用
    app.run(host='0.0.0.0', port=8080)
